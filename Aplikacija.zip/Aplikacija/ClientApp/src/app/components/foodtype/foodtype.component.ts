import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { FoodtypeService } from 'src/app/services/foodtype.service';

@Component({
  selector: 'app-foodtype',
  templateUrl: './foodtype.component.html',
  styleUrls: ['./foodtype.component.css']
})
export class FoodtypeComponent implements OnInit {
  //displayedColumns: string[] = ['id', 'name', 'storigeSpaceType', 'location'];
  dataSource: any;
  showAddFoodtype: boolean = false;
  showEditFoodtype: boolean = false;
    iD:  FormControl;
    name:  FormControl;
    unit:  FormControl;
    defaultQuantity: FormControl;
  // @ViewChild(MatPaginator)
  // paginator!: MatPaginator;
  // @ViewChild(MatSort, { static: false })
  // sort!: MatSort;
  @ViewChild(MatTable, { static: false }) table!: MatTable<FoodtypeItem>;
  foodtype: any;

  //vidii ovu liniju iznad (21) i (29) liniju koda gde je (res: ShoppinglistItem[])
  constructor(public foodtypeService: FoodtypeService) {
    this.showAddFoodtype = false;
    this.showEditFoodtype = false;
    this.iD = new FormControl();
    this.name = new FormControl();
    this.unit = new FormControl();
    this.defaultQuantity = new FormControl();
  }

  ngOnInit(): void {
    //this.dataSource = new StorigeSpaceDataSource(this.storigeSpaceService);
    this.foodtypeService.getFoodtype().subscribe(res => {
      this.dataSource = res as FoodtypeItem[];
      console.log(res);
    });
    console.log(this.dataSource);
  }

  ngAfterViewInit() {
    this.ngOnInit();
  }

  addFoodtype() {
    let foodtype: FoodtypeItem =
    {
      ID: ((this.dataSource != null)? this.dataSource.length : 0) + 1000,
      Name: this.name.value,
      Unit: this.unit.value,
      DefaultQuantity: this.defaultQuantity.value
    }
    console.log(foodtype);
    //const body=JSON.stringify(foodtype);
    this.foodtypeService.addFoodtype(foodtype).subscribe(res => console.log(res));
    this.showAddFoodtype = false;

    this.iD.setValue('');
    this.name.setValue('');
    this.unit.setValue('');
    this.defaultQuantity.setValue('');
  }

  showAdd() {
    this.showAddFoodtype = !this.showAddFoodtype;
    this.iD.setValue('');
    this.name.setValue('');
    this.unit.setValue('');
    this.defaultQuantity.setValue('');
    this.showEditFoodtype = false;
  }
  deleteFoodtype() { }

  showEdit(e: any) {
    console.log(e);
    this.iD.setValue(e.iD);
    this.name.setValue(e.name);
    this.unit.setValue(e.unit);
    this.defaultQuantity.setValue(e.defaultQuantity);
    this.showEditFoodtype = true;
    this.showAddFoodtype = false;
  }

  editFoodtype() {
    if (this.showEditFoodtype) {
      this.iD.setValue('');
      this.name.setValue('')
      this.unit.setValue('');
      this.defaultQuantity.setValue('');
    }
    else {
      this.showEditFoodtype = true;
    }
  }
}
export interface FoodtypeItem {
  ID: number;
  Name: string;
  Unit: string;
  DefaultQuantity: string;
}
