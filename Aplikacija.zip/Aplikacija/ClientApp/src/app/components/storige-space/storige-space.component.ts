import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { StoredSpaceService } from 'src/app/services/stored-space.service';

@Component({
  selector: 'app-storige-space',
  templateUrl: './storige-space.component.html',
  styleUrls: ['./storige-space.component.css']
})
export class StorigeSpaceComponent implements OnInit {
  dataSource : any;
  showAddStorigeSpace: boolean = false;
  showEditStorigeSpace: boolean = false;
  name: FormControl;
  storigeSpaceType: FormControl;
  location: FormControl;
  id: FormControl;
  // @ViewChild(MatPaginator)
  // paginator!: MatPaginator;
  // @ViewChild(MatSort, { static: false })
  // sort!: MatSort;
  @ViewChild(MatTable, { static: false }) table!: MatTable<StorigeSpacesItem>;

  constructor(public storigeSpaceService: StoredSpaceService, private toastr: ToastrService) {
    this.showAddStorigeSpace = false;
    this.showEditStorigeSpace = false;
    this.name = new FormControl();
    this.storigeSpaceType = new FormControl();
    this.location = new FormControl();
    this.id = new FormControl();
  }

  ngOnInit(): void {
    ///this.dataSource = new StorigeSpaceDataSource(this.storigeSpaceService);
    this.storigeSpaceService.getStoredSpace().subscribe(res => {
      this.dataSource = res as StorigeSpacesItem[];
      console.log(res);
    });
    console.log(this.dataSource);
  }

  ngAfterViewInit() {
    this.ngOnInit();
  }

  addStorigeSpace()
  {
    let storigeSpace: StorigeSpacesUpdate =
    {
      //ID: ((this.dataSource != null) ? this.dataSource.length : 0) + 1000,
      Name: this.name.value,
      StorigeSpaceType: this.storigeSpaceType.value,
      Location: this.location.value
    }
    console.log(storigeSpace);
    this.storigeSpaceService.addStoredSpace(storigeSpace).subscribe(res => {
      console.log(res)
      this.toastr.success('StoredSpace is created');
      this.ngOnInit();
    });
    this.showAddStorigeSpace = false;
    this.reset();

    this.id.setValue('');
    this.name.setValue('');
    this.storigeSpaceType.setValue('');
    this.location.setValue('');
  }

  showAdd()
  {
    this.id.setValue('');
    this.name.setValue('');
    this.storigeSpaceType.setValue('');
    this.location.setValue('');
    this.showAddStorigeSpace = !this.showAddStorigeSpace;
    this.showEditStorigeSpace = false;
  }

  deleteStorigeSpace(id : number)
  {
    if (confirm("Do you want to delete storige space?")) {
      this.storigeSpaceService.deleteStoredSpace(id).subscribe(res => {
        this.toastr.success('StoredSpace is deleted');
        this.ngOnInit();
      })
    }
  }

  showEdit(e : any)
  {
    console.log(e);
    this.id.setValue(e.id);
    this.name.setValue(e.name);
    this.storigeSpaceType.setValue(e.storageSpaceType);
    this.location.setValue(e.location);
    this.showEditStorigeSpace = true;
    this.showAddStorigeSpace = false;
  }
  editStorigeSpace(){
    if(this.showEditStorigeSpace)
    {
      let space = {
        ID: this.id.value,
        Name: this.name.value,
        StorigeSpaceType: this.storigeSpaceType.value,
        Location: this.location.value
      }
      this.storigeSpaceService.editStoredSpace(this.id.value, space).subscribe(res => {
        this.toastr.success('StoredSpace is edited');
        this.dataSource = [];
        this.ngOnInit();
      });

      this.name.setValue('');
      this.storigeSpaceType.setValue('');
      this.location.setValue('');
      this.showEditStorigeSpace = false;
    }
    else
    {
      this.showEditStorigeSpace = true;
    }
  }

  reset() {
    this.storigeSpaceService.getStoredSpace().subscribe(res => {
      this.dataSource = res as StorigeSpacesItem[];
    });
  }
}

export interface StorigeSpacesItem {
  ID : number;
  Name: string;
  StorigeSpaceType : number;
  Location: string;
}

export interface StorigeSpacesUpdate {
  Name: string;
  StorigeSpaceType: number;
  Location: string;
}
