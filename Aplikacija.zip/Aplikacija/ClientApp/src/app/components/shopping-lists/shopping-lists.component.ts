import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ShoppingListService } from 'src/app/services/shoppinglist.service';

@Component({
  selector: 'app-shopping-lists',
  templateUrl: './shopping-lists.component.html',
  styleUrls: ['./shopping-lists.component.css']
})
export class ShoppingListsComponent implements OnInit {
  //displayedColumns: string[] = ['id', 'name', 'storigeSpaceType', 'location'];
  dataSource: any;
  showAddShoppingList: boolean = false;
  showEditShoppingList: boolean = false;
  name: FormControl;
  createdAt: FormControl;
  id: FormControl;
  // @ViewChild(MatPaginator)
  // paginator!: MatPaginator;
  // @ViewChild(MatSort, { static: false })
  // sort!: MatSort;
  @ViewChild(MatTable, { static: false }) table!: MatTable<ShoppingListItem>;
    shoppinglist: any;

  //vidii ovu liniju iznad (21) i (29) liniju koda gde je (res: ShoppinglistItem[])
  constructor(public shoppingListService: ShoppingListService) {
    this.showAddShoppingList = false;
    this.showEditShoppingList = false;
    this.name = new FormControl();
    this.createdAt = new FormControl();
    this.id = new FormControl();
  }

  ngOnInit(): void {
    //this.dataSource = new StorigeSpaceDataSource(this.storigeSpaceService);
    this.shoppingListService.getShoppingList().subscribe(res=> {
      this.dataSource = res as ShoppingListItem[];
      console.log(res);
    });
    console.log(this.dataSource);
  }

  ngAfterViewInit() {
    this.ngOnInit();
  }

  addShoppingList() {
    let storigeSpace: ShoppingListItem =
    {
      ID: this.dataSource.lenght + 1000,
      Name: this.name.value,
      CreatedAt: this.createdAt.value
    }
    console.log(storigeSpace);
    this.shoppingListService.addShoppingList(storigeSpace).subscribe(res => console.log(res));
    this.showAddShoppingList = false;

    this.id.setValue('');
    this.name.setValue('');
    this.createdAt.setValue('');
  }

  showAdd() {
    this.id.setValue('');
    this.name.setValue('');
    this.createdAt.setValue('');
    this.showAddShoppingList = !this.showAddShoppingList;
    this.showEditShoppingList = false;
  }

  deleteShoppingList() { }

  showEdit(e: any) {
    console.log(e);
    this.id.setValue(e.iD);
    this.name.setValue(e.foodID);
    this.createdAt.setValue(e.recipeID);
    this.showEditShoppingList = true;
    this.showAddShoppingList = false;
  }
  editShoppingList() {
    if (this.showEditShoppingList) {
      this.name.setValue('');
      this.createdAt.setValue('');

    }
    else {
      this.showEditShoppingList = true;
    }
  }
}
export interface ShoppingListItem {
  ID: number;
  Name: string;
  CreatedAt: any;
}
