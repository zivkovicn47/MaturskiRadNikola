import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { FoodsService } from 'src/app/services/foods.service';
import { FoodtypeService } from 'src/app/services/foodtype.service';

@Component({
  selector: 'app-foods',
  templateUrl: './foods.component.html',
  styleUrls: ['./foods.component.css']
})
export class FoodsComponent implements OnInit {
  //displayedColumns: string[] = ['id', 'name', 'storigeSpaceType', 'location'];
  dataSource: any;
  foodTypes : any;
  showAddFood: boolean = false;
  showEditFood: boolean = false;
  iD: FormControl;
  name: FormControl;
  foodType: FormControl;
  // @ViewChild(MatPaginator)
  // paginator!: MatPaginator;
  // @ViewChild(MatSort, { static: false })
  // sort!: MatSort;
  @ViewChild(MatTable, { static: false }) table!: MatTable<FoodItem>;
  food: any;

  //vidii ovu liniju iznad (21) i (29) liniju koda gde je (res: ShoppinglistItem[])
  constructor(public foodsService: FoodsService, public foodtypeService: FoodtypeService) {
    this.showAddFood = false;
    this.showEditFood = false;
    this.iD = new FormControl();
    this.name = new FormControl();
    this.foodType = new FormControl();
    this.foodtypeService.getFoodtype().subscribe(res =>{
      this.foodTypes = res;
    });
    console.log(this.foodTypes);
  }

  ngOnInit(): void {
    this.foodsService.getFood().subscribe(res => {
      this.dataSource = res as FoodItem[];
      console.log(res);
    });
    console.log(this.dataSource);
  }

  ngAfterViewInit() {
    this.ngOnInit();
  }

  addFood() {
    let foods: FoodItem =
    {
      ID: ((this.dataSource != null)? this.dataSource.length : 0) + 1000,
      Name: this.name.value,
      FoodType: this.foodType.value
    }
    console.log(foods);
    this.foodsService.addFood(foods).subscribe(res => console.log(res));
    this.showAddFood = false;

    this.iD.setValue('');
    this.name.setValue('');
    this.foodType.setValue('');
  }

  showAdd() {
    this.showAddFood = !this.showAddFood;
    this.iD.setValue('');
    this.name.setValue('');
    this.foodType.setValue('');
    this.showEditFood = false;
  }
  deleteFood() { }

  showEdit(e: any) {
    console.log(e);
    this.iD.setValue(e.iD);
    this.name.setValue(e.name);
    this.foodType.setValue(e.foodType);
    this.showEditFood = true;
    this.showAddFood = false;
  }
  editFood() {
    if (this.showEditFood) {
      this.iD.setValue('');
      this.name.setValue('');
      this.foodType.setValue('');
    }
    else {
      this.showEditFood = true;
    }
  }
}
export interface FoodItem {
  ID: number;
  Name: string;
  FoodType: any;
}
