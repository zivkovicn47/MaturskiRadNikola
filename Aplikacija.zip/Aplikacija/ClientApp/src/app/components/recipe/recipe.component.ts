import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IngredientsService } from '../../services/ingredients.service';

@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.css']
})
export class RecipeComponent implements OnInit {
  recipe: any;
  showDialog: boolean;
  ingredients: any;

  constructor(public dialogRef: MatDialogRef<RecipeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private ingredientsService : IngredientsService){
    this.showDialog = false;
    this.recipe = {
      createAt: "2022-11-05T00:00:00",
      difficulty: 3,
      id: 3,
      minuteForPrepere: 30,
      name: "Pica",
      numberServes: 4,
      text: ''
    };
    this.recipe = this.data;
    console.log(this.data);
    this.ingredientsService.getIngredientsByRecipeId(this.recipe.id).subscribe(res => {
      this.ingredients = res;
      console.log(this.ingredients);
    });
  }

  ngOnInit(): void {
  }

  open(recipe: any) {
    this.recipe = recipe;
    this.showDialog = true;
  }
}
