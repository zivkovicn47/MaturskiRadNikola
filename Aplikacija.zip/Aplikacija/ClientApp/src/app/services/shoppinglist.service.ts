import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShoppingListService {
  baseUrl = "https://localhost:5001/api/Shoppinglist";
  constructor(private http: HttpClient) { }

  getShoppingList() {
    return this.http.get(this.baseUrl);
  }

  addShoppingList(Shoppinglist: any) {
    return this.http.post(this.baseUrl, Shoppinglist);
  }

  editShoppinglist(id: number, Shoppinglist: any) {
    return this.http.put(this.baseUrl + '/' + id, Shoppinglist);
  }

  deleteShoppinglist(id: number) {
    return this.http.delete(this.baseUrl + "/" + id);
  }
}
