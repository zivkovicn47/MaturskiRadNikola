import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FoodtypeService {
  baseUrl = "https://localhost:5001/api/FoodTypes";
  constructor(private http: HttpClient) { }

  getFoodtype(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  addFoodtype(Foodtype: any) {
    return this.http.post(this.baseUrl, Foodtype);
  }

  editFoodtype(id: number, Foodtype: any): Observable<any> {
    return this.http.put(this.baseUrl + '/' + id, Foodtype);
  }

  deleteFoodtype(id: number): Observable<any> {
    return this.http.delete(this.baseUrl + "/" + id);
  }
}
