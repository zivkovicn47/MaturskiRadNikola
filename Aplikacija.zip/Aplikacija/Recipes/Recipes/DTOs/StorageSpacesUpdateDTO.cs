﻿using Recipes.Enum;

namespace Recipes.DTOs
{
    public class StorageSpacesUpdateDTO
    {
        public string Name { get; set; }
        public StorageSpaceType StorageSpaceType { get; set; }
        public string Location { get; set; }
    }
}
