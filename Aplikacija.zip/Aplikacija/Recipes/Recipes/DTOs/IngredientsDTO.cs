﻿using Recipes.Models;

namespace Recipes.DTOs
{
    public class IngredientsDTO
    {
        public double Quantity { get; set; }
        public string Name { get; set; }
        public FoodType FoodType { get; set; }
    }
}
